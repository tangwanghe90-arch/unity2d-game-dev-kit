UNITY 2D 游戏开发工具包

先选一条路线，不要重复导入。

情况 1：已有完整 Unity 工程（有场景、有素材）
- 先备份工程。
- 只导入 01_Starter_Kit\Unity2D_Starter.unitypackage。
- 不要替换原有 Assets，不要导入 02 里的完整工程。
- 原场景能玩就只补缺的功能；最后另存为 Main.unity。
- 详细步骤看 01 里的 2D_Game_Dev_Guide.pdf。

情况 2：只有 .unitypackage 或素材，没有场景
- 新建或打开一个 2D 工程，导入 01_Starter_Kit\Unity2D_Starter.unitypackage。
- 打开 Assets/ExamKitDemo/ExamKitPlatformer.unity，按 Play，点 START 验收。
- 需要俯视射击就开 ExamKitTopDown.unity。
- 把素材拖到 Sprite Renderer 上即可替换外观。

情况 3：没有工程，从零做
- 解压 02_Full_Project\Unity2D_Full_Project.zip。
- Unity Hub 点 Add，选择解压出的 UnityUniversalTemplate 文件夹。
- 打开 Assets/Scenes/Graybox.unity，按 Play。

情况 4：时间不够，先保底
- 用 01 的 Starter Kit，开演示场景，换 2–3 张素材。
- 确认能开始、能得分、能输、能赢、能重开。
- 保存场景，拖进 File > Build Settings > Scenes In Build。

文件说明
01_Starter_Kit
- Unity2D_Starter.unitypackage：优先导入这个，18 个脚本 + 两套演示场景。
- Unity2D_Starter_Source.zip：包导入失败时，按里面 README 复制源码。
- 2D_Game_Dev_Guide.docx / .pdf / .pptx：已有工程或素材时看这本。

02_Full_Project
- Unity2D_Full_Project.zip：可直接用 Unity Hub 打开的完整工程。
- Unity2D_Project_Manual.docx / .pdf：从零做小游戏时看这本。

版本说明
- 已在 Unity 2022.3 和 Unity 6 下导入验证。
- ExamKit 使用独立命名空间，不和原有脚本重名。
- 不要上传或复制 Library、Logs、UserSettings。
